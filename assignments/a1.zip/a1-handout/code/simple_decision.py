# You don't need to use this file, but you could write your predict()
# function here if you felt like it.
def predict(X):
    raise NotImplementedError()

